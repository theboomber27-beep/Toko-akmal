# CATATAN TOKO AKMAL V3 — Tablet Workflow

Project Android native untuk dibangun tanpa PC.

## Jalur yang direkomendasikan
1. Buat repository GitHub baru dari tablet.
2. Upload seluruh isi folder project ini.
3. Buka tab **Actions**.
4. Pilih **Build CATATAN TOKO AKMAL V3**.
5. Jalankan workflow dengan **Run workflow**.
6. Setelah selesai, buka hasil run dan download artifact:
   `CATATAN-TOKO-AKMAL-V3-APK`
7. Ekstrak artifact dan instal `app-debug.apk` di Android.

GitHub Actions menyimpan file hasil build sebagai artifact yang bisa diunduh setelah workflow selesai.

## Catatan penting
- V3 ini adalah **fondasi workflow tablet** dan UI yang bisa dibuild; bukan klaim APK production final.
- Modul produksi yang masih perlu diselesaikan dan diuji di perangkat nyata: Room persistence penuh, PIN aman, backup/restore nyata, laporan PDF multi-halaman, grafik, ESC/POS Bluetooth 58/80 mm, dan pengujian lintas perangkat.
- Jangan memasukkan data toko asli ke build percobaan sebelum backup/restore dan database diuji.
- Build menggunakan JDK 17 dan Gradle 8.13 dengan AGP 8.13.2 untuk menjaga jalur build stabil di cloud.

## Struktur
- `app/` — aplikasi Android
- `.github/workflows/build-apk.yml` — build APK otomatis
- `README.md` — panduan tablet
