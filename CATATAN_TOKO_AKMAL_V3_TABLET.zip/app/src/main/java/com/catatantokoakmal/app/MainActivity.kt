package com.catatantokoakmal.app

import android.app.Activity
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.*

private enum class Jenis { OMSET, SIMPANAN, PENGELUARAN }
private data class Catatan(
    val id: Long,
    val jenis: Jenis,
    val nominal: Long,
    val keterangan: String,
    val waktu: Long
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { App() }
    }
}

@Composable
private fun App() {
    var data by remember {
        mutableStateOf(
            listOf(
                Catatan(1, Jenis.OMSET, 250000, "Penjualan hari ini", System.currentTimeMillis()),
                Catatan(2, Jenis.SIMPANAN, 100000, "Setoran simpanan", System.currentTimeMillis()),
                Catatan(3, Jenis.PENGELUARAN, 25000, "Belanja operasional", System.currentTimeMillis())
            )
        )
    }
    var tab by remember { mutableIntStateOf(0) }
    var showAdd by remember { mutableStateOf(false) }
    val totalOmset = data.filter { it.jenis == Jenis.OMSET }.sumOf { it.nominal }
    val totalSimpanan = data.filter { it.jenis == Jenis.SIMPANAN }.sumOf { it.nominal }
    val totalPengeluaran = data.filter { it.jenis == Jenis.PENGELUARAN }.sumOf { it.nominal }
    val saldo = totalSimpanan - totalPengeluaran
    val clock = remember { mutableStateOf("") }

    LaunchedEffect(Unit) {
        while (true) {
            clock.value = SimpleDateFormat("dd MMMM yyyy • HH:mm:ss", Locale("id", "ID")).format(Date())
            kotlinx.coroutines.delay(1000)
        }
    }

    MaterialTheme {
        Scaffold(
            topBar = {
                TopAppBar(title = {
                    Column {
                        Text("CATATAN TOKO AKMAL")
                        Text(clock.value, style = MaterialTheme.typography.labelSmall)
                    }
                })
            },
            floatingActionButton = {
                FloatingActionButton(onClick = { showAdd = true }) { Text("+") }
            },
            bottomBar = {
                NavigationBar {
                    listOf("Beranda", "Catatan", "Laporan", "Pengaturan").forEachIndexed { i, label ->
                        NavigationBarItem(selected = tab == i, onClick = { tab = i }, icon = {}, label = { Text(label) })
                    }
                }
            }
        ) { pad ->
            Box(Modifier.padding(pad)) {
                when (tab) {
                    0 -> Dashboard(totalOmset, totalSimpanan, totalPengeluaran, saldo)
                    1 -> Notes(data)
                    2 -> Report(totalOmset, totalSimpanan, totalPengeluaran, saldo)
                    3 -> SettingsScreen()
                }
            }
        }
    }

    if (showAdd) {
        AddDialog(
            onDismiss = { showAdd = false },
            onSave = { jenis, nominal, ket ->
                data = data + Catatan(System.nanoTime(), jenis, nominal, ket, System.currentTimeMillis())
                showAdd = false
            }
        )
    }
}

@Composable
private fun Dashboard(o: Long, s: Long, p: Long, saldo: Long) {
    LazyColumn(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { Text("Ringkasan Hari Ini", style = MaterialTheme.typography.headlineSmall) }
        item { SummaryCard("Total Omset", o) }
        item { SummaryCard("Total Simpanan", s) }
        item { SummaryCard("Total Pengeluaran", p) }
        item { SummaryCard("Sisa Saldo Simpanan", saldo) }
    }
}

@Composable
private fun SummaryCard(title: String, value: Long) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium)
            Text(rupiah(value), style = MaterialTheme.typography.headlineSmall)
        }
    }
}

@Composable
private fun Notes(data: List<Catatan>) {
    LazyColumn(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        item { Text("Buku Catatan", style = MaterialTheme.typography.headlineSmall) }
        items(data.reversed()) { c ->
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp)) {
                    Text("${c.jenis} • ${rupiah(c.nominal)}")
                    Text(c.keterangan)
                    Text(SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault()).format(Date(c.waktu)),
                        style = MaterialTheme.typography.labelSmall)
                }
            }
        }
    }
}

@Composable
private fun Report(o: Long, s: Long, p: Long, saldo: Long) {
    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("Laporan", style = MaterialTheme.typography.headlineSmall)
        Text("Omset: ${rupiah(o)}")
        Text("Simpanan: ${rupiah(s)}")
        Text("Pengeluaran: ${rupiah(p)}")
        Text("Saldo simpanan: ${rupiah(saldo)}")
        Text("V3 disiapkan dengan fondasi database, backup/restore, PIN, laporan, dan printer thermal untuk tahap produksi berikutnya.")
    }
}

@Composable
private fun SettingsScreen() {
    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Pengaturan", style = MaterialTheme.typography.headlineSmall)
        Text("Nama aplikasi: CATATAN TOKO AKMAL")
        Text("Target cetak: thermal 58/80 mm")
        Text("Build: V3 Tablet Workflow")
        Text("Build APK utama dilakukan melalui GitHub Actions agar tidak membutuhkan PC.")
    }
}

@Composable
private fun AddDialog(onDismiss: () -> Unit, onSave: (Jenis, Long, String) -> Unit) {
    var jenis by remember { mutableStateOf(Jenis.OMSET) }
    var nominal by remember { mutableStateOf("") }
    var ket by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Tambah Catatan") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    Jenis.values().forEach { j ->
                        FilterChip(selected = jenis == j, onClick = { jenis = j }, label = { Text(j.name) })
                    }
                }
                OutlinedTextField(nominal, { nominal = it.filter(Char::isDigit) }, label = { Text("Nominal") })
                OutlinedTextField(ket, { ket = it }, label = { Text("Keterangan") })
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val n = nominal.toLongOrNull() ?: 0
                if (n > 0) onSave(jenis, n, ket.ifBlank { "Tanpa keterangan" })
            }) { Text("Simpan") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Batal") } }
    )
}

private fun rupiah(v: Long): String =
    NumberFormat.getCurrencyInstance(Locale("id", "ID")).format(v).replace(",00", "")
